/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitextractor;

/**
 *
 * @author i3lack_i3erry
 */
import java.util.Scanner;
public class DigitExtractorTester {
    public static void main(String[] args){ 
        Scanner sc = new Scanner(System.in);
//        String c = " " + 1 ; 
//        int x = c.length() ;
//        System.out.println("Enter a positive number: " +x);
        System.out.print("Enter a positive number: ");
        int num = sc.nextInt();
        DigitExtractor digit = new DigitExtractor(num);
       // int digit = 12345;
        System.out.println(digit.nextDigit());
        System.out.println(digit.nextDigit());
        System.out.println(digit.nextDigit());
        System.out.println(digit.nextDigit());
        System.out.println(digit.nextDigit());
     
     //   System.out.printf("  +%20.4f",000003.1548515);
}
}
