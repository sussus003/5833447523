/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitextractor;

/**
 *
 * @author i3lack_i3erry
 */

public class DigitExtractor{
    //ประกาศ instance variable ที่เหมาะสม
    int Num;
 
    //Constructor รับเลขจำนวนเต็มที่ต้องการจะแยกออกทีละหลัก
    public DigitExtractor(int anInteger) {
    //เติมโค้ดในส่วนนี้
        Num = anInteger ;
        
    
        
     //  anInteger.replace("",'0');
}
    // คืนเลขหลักถัดไปที่ต้องการแยกออกมา
    public int nextDigit() {
        int digit = Num%10 ;
        Num = Num/10 ;
        return digit ;
    //เติมโค้ดในส่วนนี้
}
}
