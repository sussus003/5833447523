  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timeintervaltester;

import java.util.Scanner;

/**
 *
 * @author i3lack_i3erry
 */
public class TimeIntervalTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner start = new Scanner(System.in);
        System.out.print("Enter start time : ");
        int startTime = start.nextInt();
        
        Scanner end = new Scanner(System.in);
        System.out.print("Enter end time : ");
        int endTime = start.nextInt();
        
        TimeInterval test = new TimeInterval(startTime,endTime);
        
        System.out.printf("%d hours %d minutes \n",test.getHours(),test.getMinutes());
        
    }
}
//class TimeInterval{
//
//    private int startTime, endTime;
//    
//    public TimeInterval(int startTime, int endTime){
//        this.startTime = startTime;
//        this.endTime = endTime;
//    }
//    public int getHours(){
//        return startTime/100 - endTime/100 ;
//    }
//    public int getMinutes(){
//        return startTime%100 - endTime%100 ;
//    }
//
//}
    

