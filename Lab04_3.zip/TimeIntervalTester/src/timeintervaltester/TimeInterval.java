/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timeintervaltester;

/**
 *
 * @author i3lack_i3erry
 */
class TimeInterval{

    private final int startTime;
    private final int endTime;
    
    public TimeInterval(int startTime, int endTime){
        this.startTime = startTime;
        this.endTime = endTime;
    }
    public int getMinutes(){
        return endTime%100 - startTime%100  ;
    }
    public int getHours(){
        return endTime/100 - startTime/100 ;
    }
    

}