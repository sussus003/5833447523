/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sodacan;

import static sodacan.SodaCan.SodaCan;

/**
 *
 * @author i3lack_i3erry
 */
public class SodaTester {

    /**
     *
     * @param args
     */
    public static void main(String[] args){
    SodaCan();
    }
}
