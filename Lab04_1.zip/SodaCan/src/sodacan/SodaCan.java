/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sodacan;

import java.util.Scanner;

/**
 *
 * @author i3lack_i3erry
 */
class SodaCan {

    /**
     * @param args the command line arguments
     */
    static void SodaCan() {
        // TODO code application logic here
        double h,d;
        final double p = 3.141592;   
        String x;
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter height : ");
        h = input.nextDouble();
        System.out.print("Enter diameter : "); 
        d = input.nextDouble();
        System.out.printf("Volume : %.2f \n", getVolume(h,d));
        System.out.printf("Volume : %.2f \n", getSurfaceArea(h,d));
        
    }
    
    static double getVolume(double h,double d){
        return 3.141592*(d/2)*(d/2)*h;           
    }
    static double getSurfaceArea(double h,double d){
        return (2*3.141592*(d/2)*(d/2)) + (2*3.141592*(d/2)*h);           
    }
}

